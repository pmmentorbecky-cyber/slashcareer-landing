# 30 天不離職加薪計畫 — 報名頁上架說明

這個資料夾裡的 **index.html** 就是你的報名頁。
Zeabur 會自動把它辨識成「靜態網站」，並用 index.html 當首頁，你不需要寫任何設定檔。

（README.md 只是給你看的說明，不影響部署，可上傳也可不上傳。）

---

## 方法一：用 GitHub（推薦・不用終端機）

1. 解壓縮這個 zip。
2. 到 https://github.com 註冊或登入。
3. 右上角「+」→ New repository，取個名字（例如 becky-landing），可選 Private，按 Create。
4. 進入這個 repo →「Add file」→「Upload files」→ 把 index.html 拖進去 →「Commit changes」。
5. 到 https://zeabur.com，用 GitHub 帳號登入。
6.「Create Project」→ 選一個離台灣近的區域（建議 Hong Kong 或 Tokyo）。
7.「Add Service」→「GitHub」→ 授權後選你剛剛建立的 repo。
8. Zeabur 會自動部署（靜態網站，大約 1 分鐘）。
9. 部署完成後，進入該服務 →「Networking / Domains」→
   - 點「Generate Domain」拿一個免費的 xxx.zeabur.app 網址，或
   - 「Add Domain」綁定你自己的網域。
10. 打開網址確認頁面正常 → 把網址貼到 IG / 報名宣傳。

之後若要改內容：重新上傳 index.html 到同一個 repo，Zeabur 會自動重新部署。

---

## 方法二：用 Zeabur CLI（更快・需要終端機）

1. 先安裝 Node.js（https://nodejs.org）。
2. 在解壓縮後的資料夾裡開啟終端機。
3. 執行： npx zeabur@latest
4. 依畫面指示登入、選擇／建立專案，CLI 會把資料夾上傳並部署，完成後給你網址。

（詳細說明：https://zeabur.com/docs）

---

## 上架前一定要確認的兩件事

1. **倒數計時的截止時間**
   打開 index.html，搜尋 `DEADLINE`，那一行目前設定為
   `2026-06-25T22:00:00+08:00`（台灣時間 6/25 晚上 10 點）。
   請改成你「首發價真正調漲」的時間。

2. **報名按鈕**
   已經接到你的 PayUni 連結，按下「報名 / 卡位 / 搶名額」會直接前往付款頁，不需再改。
